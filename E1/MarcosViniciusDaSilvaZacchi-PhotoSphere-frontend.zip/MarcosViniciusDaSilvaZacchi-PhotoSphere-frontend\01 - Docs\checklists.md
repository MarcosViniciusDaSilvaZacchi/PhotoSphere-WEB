# Checklists — PhotoSphere | Atividade 1

> Disciplina de Programação Web — N1, Entrega 1  
> Projeto: PhotoSphere (#15)  
> Aluno: Mark V

---

## ✅ PARTE A — Backend (API)

- [x] Node.js 20+ instalado e verificado (`node -v`)
- [x] Execução de scripts liberada no PowerShell (`Set-ExecutionPolicy RemoteSigned`)
- [x] Pasta `photosphere-api/` criada
- [x] Projeto inicializado com `npm init -y` (sem scaffolding automático)
- [x] Dependências instaladas: `express`, `cors`, `dotenv`
- [x] Estrutura de pastas criada: `bin/`, `config/`, `middlewares/`, `modules/`, `routes/`
- [x] `.gitignore` criado (ignorando `node_modules/` e `.env`)
- [x] `.env` configurado com `PORT=3000` e `FRONTEND_URL=http://localhost:5173`
- [x] `middlewares/apiResponse.js` criado com padrão `{ success, message, data }` / `{ success, message, errors }`
- [x] `routes/index.js` criado com `GET /` retornando status "online"
- [x] `server.js` criado com Express + CORS + middlewares + rotas
- [x] CORS configurado via `.env`, autorizando explicitamente `http://localhost:5173`
- [x] API rodando na porta 3000 (`node server.js`)
- [x] Rota `GET /api` testada no navegador — retornou `{ success: true, data: { status: "online" } }`
- [x] Rota `GET /api` testada com `curl http://localhost:3000/api`

---

## ✅ PARTE B — Frontend (Vue)

- [x] Projeto criado com `npm create vue@latest photosphere-frontend` (Vite + Vue 3)
- [x] Opções selecionadas: Vue Router ✅ | Pinia ✅ | TypeScript ❌ | outros ❌
- [x] `npm install` executado com sucesso
- [x] `npm run dev` rodando em `http://localhost:5173`
- [x] Estrutura de pastas criada: `views/`, `components/`, `services/`, `stores/`
- [x] `.env` criado com `VITE_API_URL=http://localhost:3000/api`
- [x] Vue Router configurado com todas as rotas do sistema (16 rotas)
- [x] Views criadas para todas as rotas (inicialmente com placeholder "em construção")
- [x] `components/AppNavbar.vue` criado com `<RouterLink>` para navegação
- [x] `components/AppFooter.vue` criado
- [x] `App.vue` atualizado com layout base: `Navbar` + `RouterView` + `Footer`
- [x] `services/api.js` criado centralizando a comunicação com a API
- [x] `HomeView.vue` (Landing Page) consumindo `GET /api` e exibindo status
- [x] Badge "✅ online" aparecendo na Landing Page — **marco visual concluído**
- [x] Erro de CORS reproduzido (API sem CORS) e corrigido (com CORS via `.env`)

---

## ✅ ENTREGA — Documentação

- [x] Pasta `01 - Docs/` criada dentro de `photosphere-frontend/`
- [x] `Funcionalidades-e-Telas.md` — tabela funcionalidade → tela preenchida
- [x] `checklists.md` — este arquivo, com todos os itens marcados
- [x] `curl-api.jpg` — print do terminal com `curl.exe http://localhost:3000/api`
- [x] `landing-status.jpg` — print da Landing Page com badge "✅ online"
- [ ] `erro-cors.jpg` — print do erro de CORS no console + confirmação da correção
- [ ] ZIP do backend: `MarcosVinicius-PhotoSphere-backend.zip` (sem `node_modules/`)
- [ ] ZIP do frontend: `MarcosVinicius-PhotoSphere-frontend.zip` (sem `node_modules/`)
