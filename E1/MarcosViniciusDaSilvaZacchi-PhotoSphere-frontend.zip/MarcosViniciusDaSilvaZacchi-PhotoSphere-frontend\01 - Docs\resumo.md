# Resumo — Atividade 1: Setup da Aplicação

**Disciplina:** Programação Web (FrontEnd)
**Projeto:** PhotoSphere — Plataforma de Compartilhamento de Fotos
**Aluno:** Marcos Vinicius

---

## 1. Contexto e Objetivo

O PhotoSphere é uma plataforma web de compartilhamento de fotos onde usuários podem fazer upload de imagens, organizar álbuns, curtir e comentar publicações de outros usuários, e seguir perfis. A plataforma também conta com uma área administrativa para moderação de conteúdo e gerenciamento de categorias.

A primeira atividade da disciplina teve como objetivo construir o **alicerce técnico** da aplicação: configurar o ambiente de desenvolvimento, criar a estrutura de pastas de ambos os projetos (API e front-end), e realizar o **primeiro marco de integração** — provar que o front-end já consegue se comunicar com o back-end.

A arquitetura adotada é a de **separação total entre front-end e back-end**, dois projetos independentes que se comunicam via HTTP:

```
┌─────────────────────────────────────────────────────┐
│                    Navegador                        │
│          Vue.js rodando na porta 5173               │
│   (interface visual, lógica de apresentação)        │
└───────────────────┬─────────────────────────────────┘
                    │ requisições HTTP (fetch)
                    ▼
┌─────────────────────────────────────────────────────┐
│                  Servidor Node.js                   │
│          Express.js rodando na porta 3000           │
│    (regras de negócio, dados, autenticação)         │
└─────────────────────────────────────────────────────┘
```

Essa separação é o modelo mais utilizado no mercado hoje: o back-end fornece uma **API REST** que devolve dados em JSON, e o front-end consome esses dados e monta a interface visual.

---

## 2. Pré-requisitos e Configuração do Ambiente

### 2.1 Node.js

O Node.js é um **runtime** de JavaScript — um ambiente que permite executar código JavaScript fora do navegador, diretamente no sistema operacional. Sem ele, não é possível rodar a API nem criar o projeto Vue.

Ele vem acompanhado do **npm** (Node Package Manager), o gerenciador de pacotes que permite instalar bibliotecas de terceiros com um único comando.

Após instalar o Node.js v24 (versão LTS) pelo instalador oficial do site [nodejs.org](https://nodejs.org), a verificação no terminal confirmou a instalação:

```powershell
node -v
# v24.19.0

npm -v
# 11.x.x
```

### 2.2 Política de execução do PowerShell

O Windows, por padrão, bloqueia a execução de scripts no PowerShell por segurança. O npm utiliza scripts `.ps1` internamente, então foi necessário liberar essa política para o usuário atual:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

O parâmetro `RemoteSigned` permite rodar scripts criados localmente sem assinatura digital, enquanto exige assinatura para scripts baixados da internet. O `Scope CurrentUser` garante que a mudança afeta apenas o perfil do usuário atual, sem alterar as configurações do sistema.

---

## 3. Parte A — Construç ão da API (Back-end)

### 3.1 O que é uma API REST?

Uma **API REST** (Representational State Transfer) é um servidor que expõe recursos através de URLs chamadas **endpoints**. O cliente (neste caso, o Vue) faz requisições HTTP indicando **o que quer fazer** através do verbo HTTP, e o servidor responde com dados em JSON.

Os verbos HTTP e seus significados:

| Verbo      | Significado           | Exemplo no PhotoSphere     |
| ---------- | --------------------- | -------------------------- |
| `GET`    | Buscar/ler dados      | Listar todas as fotos      |
| `POST`   | Criar um novo recurso | Fazer upload de uma foto   |
| `PUT`    | Atualizar um recurso  | Editar legenda de uma foto |
| `DELETE` | Remover um recurso    | Deletar uma foto           |

Cada resposta também traz um **status code** numérico que indica o resultado:

| Código                       | Significado                |
| ----------------------------- | -------------------------- |
| `200 OK`                    | Requisição bem-sucedida  |
| `201 Created`               | Recurso criado com sucesso |
| `400 Bad Request`           | Dados inválidos enviados  |
| `401 Unauthorized`          | Não autenticado           |
| `404 Not Found`             | Recurso não encontrado    |
| `500 Internal Server Error` | Erro no servidor           |

### 3.2 Criando o projeto

O projeto da API foi criado do zero, sem scaffolding automático, seguindo as instruções do enunciado:

```powershell
# Criar a pasta e entrar nela
mkdir photosphere-api
cd photosphere-api

# Inicializar o projeto Node — cria o package.json
npm init -y
```

O `package.json` gerado é o **"documento de identidade"** do projeto. Ele registra o nome, a versão e, futuramente, todas as dependências instaladas:

```json
{
  "name": "photosphere-api",
  "version": "1.0.0",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "license": "ISC"
}
```

### 3.3 Instalando as dependências

Com o projeto inicializado, foram instaladas três bibliotecas essenciais:

```powershell
npm install express cors dotenv
```

- **express** → framework web minimalista para Node.js, responsável por criar rotas e gerenciar requisições/respostas HTTP
- **cors** → middleware que configura os cabeçalhos HTTP necessários para permitir requisições entre origens diferentes
- **dotenv** → carrega variáveis de configuração a partir de um arquivo `.env`, mantendo dados sensíveis fora do código-fonte

Após a instalação, o `package.json` passou a registrar as dependências:

```json
"dependencies": {
  "cors": "^2.x.x",
  "dotenv": "^16.x.x",
  "express": "^5.x.x"
}
```

A pasta `node_modules/` foi criada automaticamente com os 70 pacotes necessários (as três bibliotecas mais todas as suas dependências internas).

### 3.4 Estrutura de pastas

A estrutura de pastas foi criada seguindo o padrão modular exigido pelo enunciado:

```powershell
mkdir bin, config, middlewares, modules, routes
```

Resultado final:

```
photosphere-api/
├── bin/              ← scripts de inicialização do servidor
├── config/           ← configurações globais (banco de dados, etc.)
├── middlewares/      ← funções intermediárias entre requisição e resposta
│   └── apiResponse.js
├── modules/          ← funcionalidades do sistema (fotos, usuários, álbuns)
├── routes/           ← definição dos endpoints da API
│   └── index.js
├── node_modules/     ← dependências instaladas (não sobe pro Git)
├── .env              ← variáveis de ambiente
├── .gitignore        ← arquivos ignorados pelo Git
├── package.json
├── package-lock.json ← versões exatas das dependências
└── server.js         ← ponto de entrada do servidor
```

### 3.5 Variáveis de ambiente (.env)

Informações de configuração que podem mudar entre ambientes (desenvolvimento, produção) foram isoladas no arquivo `.env`:

```env
PORT=3000
FRONTEND_URL=http://localhost:5173
```

Este arquivo **nunca é enviado ao repositório Git** (está listado no `.gitignore`), pois pode conter senhas e chaves de API. Cada desenvolvedor cria o seu localmente.

### 3.6 Padrão de resposta — apiResponse.js

Um dos requisitos do enunciado era definir um **padrão único de resposta JSON** para toda a API. Isso garante que o front-end sempre receba os dados no mesmo formato, independente do endpoint:

```js
// middlewares/apiResponse.js
const apiResponse = (req, res, next) => {
  // Resposta de SUCESSO
  res.success = (message, data = null, statusCode = 200) => {
    return res.status(statusCode).json({
      success: true,
      message,
      data,
    });
  };

  // Resposta de ERRO
  res.error = (message, errors = null, statusCode = 400) => {
    return res.status(statusCode).json({
      success: false,
      message,
      errors,
    });
  };

  next(); // passa para o próximo middleware ou rota
};

module.exports = apiResponse;
```

Com isso, qualquer rota da API pode responder com `res.success(...)` ou `res.error(...)`, e o formato JSON será sempre:

```json
// Sucesso
{ "success": true, "message": "...", "data": { } }

// Erro
{ "success": false, "message": "...", "errors": [ ] }
```

### 3.7 CORS — comunicação entre origens

O **CORS** (Cross-Origin Resource Sharing) é um mecanismo de segurança dos navegadores. Quando o front-end (rodando na porta 5173) tenta fazer uma requisição para a API (porta 3000), o navegador entende que são **origens diferentes** e bloqueia a requisição por padrão.

```
❌ Sem CORS configurado:
Vue (localhost:5173) ──── GET /api ────► API (localhost:3000)
                     ◄─── BLOQUEADO pelo browser ────

✅ Com CORS configurado:
Vue (localhost:5173) ──── GET /api ────► API (localhost:3000)
                     ◄─── 200 OK + dados ────
```

O servidor precisa retornar cabeçalhos HTTP específicos autorizando a origem do front-end. No Express, isso é feito pelo middleware `cors`:

```js
app.use(cors({
  origin: process.env.FRONTEND_URL, // http://localhost:5173
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
```

### 3.8 O servidor (server.js)

O arquivo `server.js` é o ponto de entrada da aplicação — ele junta todos os middlewares e rotas e inicializa o servidor:

```js
require('dotenv').config(); // carrega o .env

const express = require('express');
const cors    = require('cors');
const apiResponse = require('./middlewares/apiResponse');
const routes  = require('./routes');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: process.env.FRONTEND_URL }));
app.use(express.json());      // interpreta corpo das requisições como JSON
app.use(apiResponse);         // adiciona res.success() e res.error()

app.use('/api', routes);      // monta as rotas em /api

app.listen(PORT, () => {
  console.log(`✅ PhotoSphere API rodando em http://localhost:${PORT}`);
});
```

Com a API rodando, a rota `GET /api` pode ser testada diretamente no navegador ou via `curl` no terminal:

```powershell
curl http://localhost:3000/api
```

Resposta esperada:

```json
{
  "success": true,
  "message": "PhotoSphere API online",
  "data": {
    "status": "online",
    "version": "1.0.0"
  }
}
```

---

## 4. Parte B — Construção do Front-end (Vue.js)

### 4.1 O que é o Vue.js e o Vite?

**Vue.js** é um framework JavaScript progressivo para construção de interfaces de usuário. Ele segue o modelo de **componentes** — cada parte da interface (navbar, card de foto, modal) é encapsulada em um arquivo `.vue` com seu próprio HTML, JavaScript e CSS.

**Vite** é o servidor de desenvolvimento e bundler utilizado pelo Vue. Ele é extremamente rápido e possui **hot reload**: qualquer alteração salva no código aparece instantaneamente no navegador, sem precisar recarregar a página manualmente.

O projeto foi criado com a ferramenta oficial `create-vue`:

```powershell
npm create vue@latest photosphere-frontend
```

Durante a criação, foram selecionados dois recursos adicionais:

- **Vue Router** → gerenciamento de navegação entre páginas
- **Pinia** → gerenciamento de estado global da aplicação

### 4.2 Single Page Application (SPA)

O Vue cria uma **SPA** — Single Page Application. Isso significa que existe apenas um arquivo HTML (`index.html`) e o Vue injeta o conteúdo dinamicamente conforme o usuário navega. A página **nunca recarrega de verdade**.

```
index.html (único arquivo HTML)
  └── <div id="app">
        └── App.vue (sempre visível)
              ├── AppNavbar.vue  ← fixo
              ├── <RouterView /> ← troca conforme a URL
              └── AppFooter.vue  ← fixo
```

O Vue Router intercepta os cliques nos links e troca apenas o componente dentro do `<RouterView />`, dando a sensação de navegação sem recarregar.

### 4.3 Estrutura de pastas

```
photosphere-frontend/src/
├── App.vue              ← componente raiz
├── main.js              ← ponto de entrada, inicializa o Vue
├── router/
│   └── index.js         ← mapeamento URL → View
├── stores/              ← estado global (Pinia)
├── views/               ← páginas completas da aplicação
│   ├── HomeView.vue     → /
│   ├── LoginView.vue    → /login
│   ├── FeedView.vue     → /feed
│   └── ...
├── components/          ← peças reutilizáveis
│   ├── AppNavbar.vue
│   └── AppFooter.vue
└── services/
    └── api.js           ← comunicação com a API
```

### 4.4 Vue Router — mapeando as telas

O Vue Router associa cada URL a uma View. O arquivo `router/index.js` define todas as rotas do sistema:

```js
import { createRouter, createWebHistory } from 'vue-router'
import HomeView    from '@/views/HomeView.vue'
import LoginView   from '@/views/LoginView.vue'
import FeedView    from '@/views/FeedView.vue'
// ... demais imports

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/',                 name: 'home',    component: HomeView },
    { path: '/login',            name: 'login',   component: LoginView },
    { path: '/feed',             name: 'feed',    component: FeedView },
    { path: '/photo/:id',        name: 'photo',   component: PhotoDetailView },
    { path: '/profile/:username',name: 'profile', component: ProfileView },
    // ... 16 rotas no total
  ],
})

export default router
```

As rotas com `:id` e `:username` são **rotas dinâmicas** — o valor é capturado da URL e fica disponível na View via `route.params`. Por exemplo, `/photo/42` faz com que `route.params.id === '42'`.

O sistema possui **16 rotas** no total, divididas em três grupos:

| Grupo                | Rotas | Exemplo                                             |
| -------------------- | ----- | --------------------------------------------------- |
| Públicas            | 4     | `/`, `/login`, `/register`, `/explore`      |
| Usuário autenticado | 8     | `/feed`, `/upload`, `/albums`, `/photo/:id` |
| Administrador        | 4     | `/admin`, `/admin/categories`, `/admin/users` |

### 4.5 Componentes Vue — anatomia de um .vue

Cada arquivo `.vue` possui até três seções:

```vue
<script setup>
// Lógica JavaScript do componente
import { ref, onMounted } from 'vue'

const titulo = ref('PhotoSphere') // variável reativa
</script>

<template>
  <!-- HTML do componente -->
  <h1>{{ titulo }}</h1>
</template>

<style scoped>
/* CSS exclusivo deste componente */
h1 { color: #1a1a2e; }
</style>
```

O `<script setup>` utiliza a **Composition API** do Vue 3 — o estilo moderno de escrever componentes. O `scoped` no `<style>` garante que os estilos CSS só afetam este componente, evitando conflitos.

### 4.6 Reatividade com ref()

O Vue atualiza a tela automaticamente quando uma variável reativa muda. O `ref()` é a forma de criar essas variáveis:

```js
const loading   = ref(true)   // começa como true
const apiStatus = ref(null)   // começa como null

// quando apiStatus.value muda, o HTML atualiza sozinho:
apiStatus.value = 'online'    // ← o badge na tela muda imediatamente
```

No template, `v-if`, `v-else-if` e `v-else` controlam o que é exibido:

```html
<span v-if="loading">⏳ verificando...</span>
<span v-else-if="error">❌ offline</span>
<span v-else>✅ {{ apiStatus }}</span>
```

### 4.7 Service de API — services/api.js

Toda a comunicação com a API foi centralizada em um único arquivo de serviço. Isso evita repetição de código e facilita manutenção — se a URL da API mudar, basta alterar em um único lugar:

```js
// services/api.js
const BASE_URL = import.meta.env.VITE_API_URL // lê o .env

async function get(endpoint) {
  const response = await fetch(`${BASE_URL}${endpoint}`)
  if (!response.ok) throw new Error(`Erro: ${response.status}`)
  return response.json()
}

async function checkStatus() {
  const result = await get('/')
  return result.data // { status: 'online', version: '1.0.0' }
}

export const apiService = { get, checkStatus }
```

O `fetch()` é a API nativa do navegador para fazer requisições HTTP. O `async/await` torna o código assíncrono mais legível — sem ele, seria necessário encadear `.then().catch()`.

---

## 5. Marco de Integração — Front-end conversando com a API

O objetivo final da atividade foi fazer a Landing Page consumir a rota `GET /api` e exibir o status em tempo real. Isso comprova que os dois projetos estão se comunicando corretamente.

Na `HomeView.vue`, o `onMounted()` executa assim que o componente aparece na tela e faz a requisição à API:

```js
onMounted(async () => {
  try {
    const data = await apiService.checkStatus()
    apiStatus.value = data.status     // 'online'
  } catch (err) {
    error.value = 'Não foi possível conectar à API.'
  } finally {
    loading.value = false
  }
})
```

O fluxo completo de comunicação:

```
1. Usuário acessa http://localhost:5173
2. Vue carrega o App.vue → monta a HomeView
3. onMounted() executa → chama apiService.checkStatus()
4. fetch('http://localhost:3000/api') é disparado
5. O navegador verifica os cabeçalhos CORS da resposta
6. API responde: { success: true, data: { status: 'online' } }
7. apiStatus.value = 'online'
8. Vue detecta a mudança e atualiza o badge na tela: ✅ online
```

Com os dois servidores rodando simultaneamente — API na porta 3000 e Vue na porta 5173 — o badge verde `✅ online` aparece na Landing Page, confirmando a integração bem-sucedida.

---

## 6. Conclusão

Ao final da Atividade 1, foram construídos dois projetos completos e funcionais do zero:

**Back-end (photosphere-api):**

- Servidor Node.js + Express na porta 3000
- Estrutura modular com middlewares, rotas e configurações isoladas
- Padrão único de resposta JSON
- CORS configurado via variáveis de ambiente
- Endpoint público `GET /api` respondendo corretamente

**Front-end (photosphere-frontend):**

- Aplicação Vue 3 + Vite na porta 5173
- 16 rotas mapeadas com Vue Router, cobrindo todas as funcionalidades do sistema
- Layout base com Navbar e Footer presentes em todas as páginas
- Camada de serviço centralizada para comunicação com a API
- Landing Page exibindo o status da API em tempo real

A arquitetura de separação entre front-end e back-end, a comunicação via HTTP/JSON e o gerenciamento de CORS são fundamentos que sustentarão todas as funcionalidades a serem desenvolvidas nas próximas aulas da disciplina.
