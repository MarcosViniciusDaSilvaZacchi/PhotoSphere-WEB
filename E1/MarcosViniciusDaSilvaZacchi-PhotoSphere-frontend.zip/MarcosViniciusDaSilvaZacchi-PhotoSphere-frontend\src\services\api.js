// services/api.js
// Camada de serviço responsável por toda comunicação com a API.
// Centraliza a URL base e os cabeçalhos padrão.
// Todas as Views e Stores usam este arquivo para fazer requisições.

const BASE_URL = import.meta.env.VITE_API_URL // http://localhost:3000/api

/**
 * Faz uma requisição GET para a API.
 * @param {string} endpoint - caminho relativo (ex: '/', '/fotos', '/usuarios')
 * @returns {Promise<object>} - dados retornados pela API
 */
async function get(endpoint) {
  const response = await fetch(`${BASE_URL}${endpoint}`)

  if (!response.ok) {
    throw new Error(`Erro na requisição: ${response.status}`)
  }

  return response.json()
}

/**
 * Verifica se a API está online.
 * Consome GET /api e retorna o objeto { status, version }.
 */
async function checkStatus() {
  const result = await get('/')
  return result.data // { status: 'online', version: '1.0.0' }
}

export const apiService = {
  get,
  checkStatus,
}
