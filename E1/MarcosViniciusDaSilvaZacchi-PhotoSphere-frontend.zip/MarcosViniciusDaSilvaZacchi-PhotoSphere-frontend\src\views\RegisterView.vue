<template>
  <div>Cadastro — em construção</div>
</template>
