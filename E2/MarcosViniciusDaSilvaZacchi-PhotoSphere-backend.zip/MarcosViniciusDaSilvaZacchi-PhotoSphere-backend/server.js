// server.js
// Ponto de entrada da API. Configura o Express, middlewares e rotas,
// e inicializa o servidor na porta definida no .env

require('dotenv').config(); // carrega as variáveis do .env

const express = require('express');
const cors = require('cors');
const apiResponse = require('./middlewares/apiResponse');
const routes = require('./routes');
const searchRoutes = require('./modules/search/searchRoutes'); // E2: módulo de busca

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Middlewares globais ────────────────────────────────────────────────────

// CORS: autoriza apenas o frontend (definido no .env) a chamar esta API
app.use(cors({
  origin: process.env.FRONTEND_URL,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Interpreta o corpo das requisições como JSON
app.use(express.json());

// Adiciona res.success() e res.error() em todas as rotas
app.use(apiResponse);

// ─── Rotas ──────────────────────────────────────────────────────────────────

// Rota pública: GET /api
app.use('/api', routes);

// Módulo de busca: GET /api/search
app.use('/api', searchRoutes);

// Rota 404 — qualquer endereço não mapeado cai aqui
app.use((req, res) => {
  res.error('Rota não encontrada', null, 404);
});

// ─── Inicialização ──────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`✅ PhotoSphere API rodando em http://localhost:${PORT}`);
  console.log(`🌐 CORS autorizado para: ${process.env.FRONTEND_URL}`);
});
