/**
 * modules/user/userController.js — Controlador de usuários.
 */

const userService = require('./userService');

exports.register = async (req, res) => {
  const { username, email, password, fullName } = req.body;
  const newUser = await userService.registerUser(username, email, password, fullName);
  return res.success('Conta criada com sucesso! Faça login para continuar.', newUser, 201);
};

exports.getPublicProfile = async (req, res) => {
  const user = await userService.getPublicProfile(req.params.username);
  return res.success('Perfil obtido com sucesso', user);
};
