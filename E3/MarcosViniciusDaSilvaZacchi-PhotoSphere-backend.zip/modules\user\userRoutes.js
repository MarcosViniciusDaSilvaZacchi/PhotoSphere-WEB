/**
 * modules/user/userRoutes.js — Rotas do módulo de usuários.
 */

const express = require('express');
const router = express.Router();
const userController = require('./userController');
const { registerValidator } = require('./userValidator');
const asyncHandler = require('../../middlewares/asyncHandler');

// POST /api/register - cadastro de novos usuários
router.post('/register', registerValidator, asyncHandler(userController.register));

// GET /api/profile/:username - perfil público
router.get('/profile/:username', asyncHandler(userController.getPublicProfile));

module.exports = router;
