<script setup>
import { RouterLink } from 'vue-router'
</script>

<template>
  <header class="navbar">
    <div class="navbar__brand">
      <!-- RouterLink navega sem recarregar a página -->
      <RouterLink to="/">📸 PhotoSphere</RouterLink>
    </div>

    <nav class="navbar__links">
      <RouterLink to="/explore">Explorar</RouterLink>
      <RouterLink to="/feed">Feed</RouterLink>
      <RouterLink to="/upload">Upload</RouterLink>
      <RouterLink to="/albums">Álbuns</RouterLink>
    </nav>

    <div class="navbar__auth">
      <RouterLink to="/login">Entrar</RouterLink>
      <RouterLink to="/register">Cadastrar</RouterLink>
    </div>
  </header>
</template>

<style scoped>
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 2rem;
  height: 60px;
  background-color: #1a1a2e;
  color: #fff;
  position: sticky;
  top: 0;
  z-index: 100;
}

.navbar__brand a {
  color: #fff;
  text-decoration: none;
  font-size: 1.25rem;
  font-weight: bold;
}

.navbar__links,
.navbar__auth {
  display: flex;
  gap: 1.5rem;
}

.navbar__links a,
.navbar__auth a {
  color: #ccc;
  text-decoration: none;
  font-size: 0.95rem;
  transition: color 0.2s;
}

.navbar__links a:hover,
.navbar__auth a:hover,
.navbar__links a.router-link-active,
.navbar__auth a.router-link-active {
  color: #fff;
}
</style>
