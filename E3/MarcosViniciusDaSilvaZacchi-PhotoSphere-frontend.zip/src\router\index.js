import { createRouter, createWebHistory } from 'vue-router'

// ── Rotas Públicas ──────────────────────────────────────────────────────────
import HomeView          from '@/views/HomeView.vue'
import LoginView         from '@/views/LoginView.vue'
import RegisterView      from '@/views/RegisterView.vue'
import ExploreView       from '@/views/ExploreView.vue'

// ── Rotas de Usuário Autenticado ────────────────────────────────────────────
import FeedView          from '@/views/FeedView.vue'
import UploadView        from '@/views/UploadView.vue'
import AlbumsView        from '@/views/AlbumsView.vue'
import AlbumDetailView   from '@/views/AlbumDetailView.vue'
import PhotoDetailView   from '@/views/PhotoDetailView.vue'
import ProfileView       from '@/views/ProfileView.vue'
import SettingsView      from '@/views/SettingsView.vue'

// ── Rotas de Administrador ──────────────────────────────────────────────────
import AdminDashboardView   from '@/views/admin/AdminDashboardView.vue'
import AdminCategoriesView  from '@/views/admin/AdminCategoriesView.vue'
import AdminUsersView       from '@/views/admin/AdminUsersView.vue'
import AdminModerationView  from '@/views/admin/AdminModerationView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [

    // ── Públicas ─────────────────────────────────────────────────────────
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView,
    },
    {
      path: '/register',
      name: 'register',
      component: RegisterView,
    },
    {
      path: '/explore',
      name: 'explore',
      component: ExploreView,
    },

    // ── Usuário autenticado ───────────────────────────────────────────────
    {
      path: '/feed',
      name: 'feed',
      component: FeedView,
    },
    {
      path: '/upload',
      name: 'upload',
      component: UploadView,
    },
    {
      path: '/albums',
      name: 'albums',
      component: AlbumsView,
    },
    {
      path: '/albums/:id',       // :id = parâmetro dinâmico (ex: /albums/42)
      name: 'album-detail',
      component: AlbumDetailView,
    },
    {
      path: '/photo/:id',        // :id = parâmetro dinâmico (ex: /photo/7)
      name: 'photo-detail',
      component: PhotoDetailView,
    },
    {
      path: '/profile/:username', // ex: /profile/markv
      name: 'profile',
      component: ProfileView,
    },
    {
      path: '/settings',
      name: 'settings',
      component: SettingsView,
    },

    // ── Administrador ─────────────────────────────────────────────────────
    {
      path: '/admin',
      name: 'admin',
      component: AdminDashboardView,
    },
    {
      path: '/admin/categories',
      name: 'admin-categories',
      component: AdminCategoriesView,
    },
    {
      path: '/admin/users',
      name: 'admin-users',
      component: AdminUsersView,
    },
    {
      path: '/admin/moderation',
      name: 'admin-moderation',
      component: AdminModerationView,
    },
  ],
})

export default router
