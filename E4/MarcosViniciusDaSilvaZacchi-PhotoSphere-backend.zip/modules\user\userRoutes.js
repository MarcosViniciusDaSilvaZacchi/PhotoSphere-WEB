/**
 * modules/user/userRoutes.js — Rotas do módulo de usuários.
 */

const express = require('express');
const router = express.Router();
const userController = require('./userController');
const { registerValidator, loginValidator } = require('./userValidator');
const { isAuthenticated } = require('../../middlewares/auth');
const asyncHandler = require('../../middlewares/asyncHandler');

// POST /api/register - cadastro de novos usuários
router.post('/register', registerValidator, asyncHandler(userController.register));

// POST /api/login - autenticação com geração de token JWT
router.post('/login', loginValidator, asyncHandler(userController.login));

// POST /api/logout - encerramento de sessão
router.post('/logout', asyncHandler(userController.logout));

// ⚠️ ATENÇÃO: /profile/me DEVE vir antes de /profile/:username,
// caso contrário o Express interpretará "me" como o parâmetro :username!
router.get('/profile/me', isAuthenticated, asyncHandler(userController.getMyProfile));

// GET /api/profile/:username - perfil público
router.get('/profile/:username', asyncHandler(userController.getPublicProfile));

module.exports = router;
