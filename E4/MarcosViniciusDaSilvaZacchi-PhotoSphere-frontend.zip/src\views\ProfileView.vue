<template>
  <div>Perfil de usuário — em construção</div>
</template>
